//Olivia Knight CSCI 2210-01 August 24,2020
//Introducing myself

package com.example.helloworld;

public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, my name is Olivia Knight");
        System.out.println("I'm a second year Computer Science major");
        System.out.println("I only have a small amount of knowledge on Java, but I'm excited to learn more!");

    }
}
